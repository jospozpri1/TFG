package com.dam.invernadero.model;

import java.util.List;

public class ReeResponse {
    private List<Included> included;

    public List<Included> getIncluded() {
        return included;
    }

    public void setIncluded(List<Included> included) {
        this.included = included;
    }
}
