package com.dam.invernadero.model;

public class Precio {
    private String datetime;
    private double value;

    public String getDatetime() {
        return datetime;
    }

    public double getValue() {
        return value;
    }
}
