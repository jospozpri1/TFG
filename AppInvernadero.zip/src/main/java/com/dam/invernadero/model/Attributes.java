package com.dam.invernadero.model;

import java.util.List;

public class Attributes {
    private List<Precio> values;

    public List<Precio> getValues() {
        return values;
    }

    public void setValues(List<Precio> values) {
        this.values = values;
    }
}
