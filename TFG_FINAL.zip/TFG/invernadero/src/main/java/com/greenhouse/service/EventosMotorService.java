package com.greenhouse.service;

import com.greenhouse.model.EventosMotor;
import java.util.List;

public interface EventosMotorService {
    List<EventosMotor> obtenerEventos();
}

